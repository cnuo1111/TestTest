#!/usr/bin/env bash
set -euo pipefail

# ---------------- 固定参数 ----------------
START=1048576          # 1 MiB
END=268435456          # 256 MiB
INCR=1048576           # 1 MiB

# DEVICE=0
# OUTCSV="bandwidth4060.csv"
# MAKE_ARGS='SMS="89"'

# DEVICE=1
# OUTCSV="bandwidth3060.csv"
# MAKE_ARGS='SMS="86"'

# DEVICE=2
# OUTCSV="bandwidth2060s.csv"
# MAKE_ARGS='SMS="75"'

# DEVICE=0
# OUTCSV="bandwidth5060ti.csv"
# MAKE_ARGS='SMS="120"'

# DEVICE=0
# OUTCSV="bandwidthA100-40.csv"
# MAKE_ARGS='SMS="80"'

# DEVICE=0
# OUTCSV="bandwidthA100-80.csv"
# MAKE_ARGS='SMS="80"'

DEVICE=0
OUTCSV="bandwidthH100.csv"
MAKE_ARGS='SMS="90"'

# ---------------- build ----------------
echo "[INFO] make -j ${MAKE_ARGS}"
make -j ${MAKE_ARGS}

# ---------------- run ----------------
./bandwidthTest \
  --device="${DEVICE}" \
  --mode=range \
  --start="${START}" \
  --end="${END}" \
  --increment="${INCR}" \
  --dtod \
  --d2d_csv="${OUTCSV}" \
  > /dev/null

echo "[DONE] Wrote: ${OUTCSV}"
