#!/usr/bin/env python3
"""
Plot D2D bandwidth curve and mark plateau bandwidth.
"""

import csv
import matplotlib.pyplot as plt

# =========================
# 固定路径配置
# =========================
# GPU_MODEL = "RTX 4060 8GB"
# INPUT_CSV  = "bandwidth4060.csv"
# OUTPUT_PNG = "bandwidth4060.png"

# GPU_MODEL = "RTX 3060 12GB"
# INPUT_CSV  = "bandwidth3060.csv"
# OUTPUT_PNG = "bandwidth3060.png"

# GPU_MODEL = "RTX 2060 SUPER 8GB"
# INPUT_CSV  = "bandwidth2060s.csv"
# OUTPUT_PNG = "bandwidth2060s.png"

# GPU_MODEL = "RTX 5060 Ti 16GB"
# INPUT_CSV  = "bandwidth5060ti.csv"
# OUTPUT_PNG = "bandwidth5060ti.png"

GPU_MODEL = "A100 40GB"
INPUT_CSV  = "bandwidthA100-40.csv"
OUTPUT_PNG = "bandwidthA100-40.png"

# GPU_MODEL = "A100 80GB"
# INPUT_CSV  = "bandwidthA100-80.csv"
# OUTPUT_PNG = "bandwidthA100-80.png"

# GPU_MODEL = "H100 80GB"
# INPUT_CSV  = "bandwidthH100.csv"
# OUTPUT_PNG = "bandwidthH100.png"

TITLE = f"D2D memcpy bandwidth ({GPU_MODEL})"
X_LABEL = "Transfer size (MiB)"
Y_LABEL = "Bandwidth (GiB/s)"

# =========================
# 参数：平台区定义
# =========================
PLATEAU_MIN_MB = 64    # >= 64 MiB 视为平台区

# =========================
# 读取 CSV
# =========================
sizes_mb = []
bandwidths = []

with open(INPUT_CSV, newline="") as f:
    reader = csv.reader(f)
    for row in reader:
        if not row:
            continue
        size_bytes = int(row[0])
        bw_gbps = float(row[1])

        sizes_mb.append(size_bytes / (1024 * 1024))  # Bytes -> MiB
        bandwidths.append(bw_gbps)

if not sizes_mb:
    raise RuntimeError("No data loaded from CSV")

# =========================
# 计算平台带宽
# =========================
plateau_vals = [
    bw for size, bw in zip(sizes_mb, bandwidths)
    if size >= PLATEAU_MIN_MB
]

if not plateau_vals:
    raise RuntimeError("No data points in plateau region")

plateau_bw = sum(plateau_vals) / len(plateau_vals)

# =========================
# 绘图
# =========================
fig, ax = plt.subplots(figsize=(8, 5))

ax.plot(
    sizes_mb,
    bandwidths,
    marker="o",
    linestyle="-",
    markersize=3,
    linewidth=1.0,
    label="Measured bandwidth"
)

# 平台水平线
ax.axhline(
    plateau_bw,
    color="red",
    linestyle="--",
    linewidth=1.5
)

ax.set_xlabel(X_LABEL)
ax.set_ylabel(Y_LABEL)
ax.set_title(TITLE)

ax.set_xlim(0, 260)
ax.grid(True, linestyle="--", alpha=0.6)

# =========================
# 平台带宽数值标注：虚线下方、图内右侧
# =========================
ax.annotate(
    f"{plateau_bw:.1f}",
    xy=(0.98, plateau_bw),                  # 右侧位置，高度=平台线
    xycoords=("axes fraction", "data"),
    xytext=(0, -6),                         # 向下偏移 6 pt（关键）
    textcoords="offset points",
    color="red",
    fontsize=10,
    fontweight="bold",
    va="top",                               # 从文字顶部往下贴
    ha="right",
    bbox=dict(
        boxstyle="round,pad=0.2",
        fc="white",
        ec="none",
        alpha=0.75
    ),
    clip_on=True
)


plt.tight_layout()
plt.savefig(OUTPUT_PNG, dpi=200)

print(f"Plateau bandwidth ≈ {plateau_bw:.2f} GB/s")
print(f"Saved plot to: {OUTPUT_PNG}")
